from tkinter import *
master = Tk()

b = Button(master, text='Button', height = 3, width = 10, anchor = CENTER,
foreground = 'Blue', activebackground = 'Red')
b.pack()

l = Label(master, text='Label', fg='green', font=('Helvetica', 15) )
l.pack()

mainloop()
