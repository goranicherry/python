class Person:
    def __init__(self, name):
        self.name = name

    def Hello(self):
        print('Hello, my name is', self.name)

    def __del__(self):
        print(self.name, 'says bye!')

p = Person("Hong Gildong")  # Object instantiation syntax
print(p.name)               # Attributes invoke 
p.Hello()                   # methods invoke
