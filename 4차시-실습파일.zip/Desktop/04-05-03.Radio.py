# Button, Entry, Radiobutton 예제

from tkinter import *
from tkinter import ttk

def donothing(obj_type):
    resultsContents.set("Object=" + obj_type)
    
# Frame
frame = ttk.Frame()
frame['padding'] = (5,10)
frame['borderwidth'] = 2
frame['relief']='sunken'
frame.grid()

# Label
label = ttk.Label(text='Full name :')
resultsContents = StringVar()
label['textvariable'] = resultsContents
resultsContents.set('New value to display')
label.grid()

# button
button = ttk.Button(text='Okay', command=lambda: donothing("Button"))
button.grid()

# checkbutton
measureSystem = StringVar()
check = ttk.Checkbutton(text='Use Metric',command=lambda: donothing("Checkbutton"),
                        variable=measureSystem, onvalue='metric', offvalue='imperial')
check.instate(['alternate'])
check.grid()

# radiobutton
phone = StringVar()
home = ttk.Radiobutton(text='Home', variable=phone, value='home', command=lambda: donothing("Radiobutton"))
office = ttk.Radiobutton(text='Office', variable=phone, value='office', command=lambda: donothing("Radiobutton"))
cell = ttk.Radiobutton(text='Mobile', variable=phone, value='cell', command=lambda: donothing("Radiobutton"))
home.grid()
office.grid()
cell.grid()

# Entry
username = StringVar()
name = ttk.Entry(textvariable=username)
name.grid()

print('current value is %s' % name.get())
name.delete(0,'end')
name.insert(0, 'your name is	')

# combobox
countryvar = StringVar()
country = ttk.Combobox(textvariable=countryvar)
country.bind('<<ComboboxSelected>>')
country['values'] = ('USA', 'Canada', 'Australia')
country.grid()

frame.mainloop()
