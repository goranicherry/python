from tkinter import Tk, Button
from time import strftime, localtime

def clicked():
    time = strftime('Day: %d %b %Y \nTime: %H : %M : %S %p\n', localtime())
    print(time)
    
root =Tk() 

# create button
but = Button( root, text='click it', command=clicked)
but.pack()
root.mainloop()
