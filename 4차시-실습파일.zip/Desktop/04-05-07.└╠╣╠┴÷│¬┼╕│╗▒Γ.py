#이미지 나타내기

from tkinter import Tk, Canvas
from PIL import ImageTk, Image
import os

root =Tk()

canvas = Canvas(root, width=600, height=400)
canvas.pack()

#image
os.chdir(os.path.dirname(os.path.realpath(__file__)))
im = Image.open('./image/acat.jpg')
canvas.image = ImageTk.PhotoImage(im)

canvas.create_image(0, 0, image=canvas.image, anchor='nw')

root.mainloop()
