# 연습문제 2-코드

from tkinter import *
from tkinter import Tk, Canvas
from PIL import ImageTk, Image
import os

root =Tk()
canvas = Canvas(root, width=400, height=300)
canvas.pack()

def oneclick(event) :
	im = Image.open('./image/adog.jpg')
	canvas.image = ImageTk.PhotoImage(im)
	canvas.create_image(0, 0, image=canvas.image, anchor='nw')
def doubleclick(event) :
	im = Image.open('./image/acat.jpg')
	canvas.image = ImageTk.PhotoImage(im)
	canvas.create_image(0, 0, image=canvas.image, anchor='nw')
	
os.chdir(os.path.dirname(os.path.realpath(__file__)))
widget = Button(None, text='Mouse Clicks')
widget.pack()

widget.bind('<Button-1>', oneclick)
widget.bind('<Double-1>', doubleclick)

root.mainloop()

